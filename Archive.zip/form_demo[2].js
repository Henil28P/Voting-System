// Filename: vote.js //

// After pressing the "let's vote" button as an event listener //
function move() {
  document.getElementById("instr").style.display = "none"; // disappear instructions //
  document.getElementById("container").style.display = "block"; // display first container //
  document.getElementById("member1").style.display = "block"; // display "next member" button as id of "member1"
  document.getElementById('move').style.display = "none"; // disappear the "let's vote" button
  document.getElementById('icon1').style.display = "block"; // display the right-sided arrow from HTML //
  // display the left-sided arrow from HTML //

}

var one2 = document.getElementById('one1'); 
  var two2 = document.getElementById('two1'); 
  var three2 = document.getElementById('three1');
  var four2 = document.getElementById('four1'); 
  var five2 = document.getElementById('five1');
  var none2 = document.getElementById("NA2");


// After pressing the "next member" button as an event listener //
function member1() {
  var one = document.getElementById('one');
  var two = document.getElementById('two'); 
  var three = document.getElementById('three');
  var four = document.getElementById('four'); 
  var five = document.getElementById('five');
  var none = document.getElementById("NA");

  if (one.checked == true || two.checked == true || three.checked == true || four.checked == true || five.checked == true || none.checked == true) {
      document.getElementById('container').style.display = "none";
      document.getElementById('container_1').style.display = "block";
      document.getElementById('member1').style.display = "none";
      document.getElementById('member2').style.display = "block";
      document.getElementById('icon2').style.display = "block";
      document.getElementById('icon_2').style.display = "block";
      document.getElementById('member_two').style.display = "block";

  } else {
      alert("Please select any one preference to go to next member");
  }

  // For locally Storing the selected preference //
  var selection = document.getElementsByName('radio');

  for (let i = 0; i < selection.length; i++) {
      if (selection[i].checked) {
          localStorage.setItem("preference1", selection[i].value);
      }
  }

  if (document.getElementById('one').checked){
    document.getElementById("one1").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('one2').disabled = true;
    document.getElementById('one3').disabled = true;
    document.getElementById('one4').disabled = true;
    document.getElementById('one5').disabled = true;
  } 
  else {
    console.log("hi");
  }
  
  if (document.getElementById('two').checked) {
    document.getElementById("two1").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('two2').disabled = true;
    document.getElementById('two3').disabled = true;
    document.getElementById('two4').disabled = true;
    document.getElementById('two5').disabled = true;
  }
  else {
  console.log("yo");
  }
  
  if (document.getElementById('three').checked) {
  document.getElementById("three1").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('three2').disabled = true;
    document.getElementById('three3').disabled = true;
    document.getElementById('three4').disabled = true;
    document.getElementById('three5').disabled = true;
  }
  else {
  console.log("yoyo");
  }
  
  if (document.getElementById('four').checked) {
  document.getElementById("four1").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('four2').disabled = true;
    document.getElementById('four3').disabled = true;
    document.getElementById('four4').disabled = true;
    document.getElementById('four5').disabled = true;
  }
  else {
  console.log('hehe');
  }
  
  if (document.getElementById('five').checked) {
  document.getElementById("five1").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('five2').disabled = true;
    document.getElementById('five3').disabled = true;
    document.getElementById('five4').disabled = true;
    document.getElementById('five5').disabled = true;
  }
  else {
  console.log('lol');
  }

  if (document.getElementById('NA').checked) {
    document.getElementById("NA2").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('NA3').disabled = true;
    document.getElementById('NA4').disabled = true;
    document.getElementById('NA5').disabled = true;
    document.getElementById('NA6').disabled = true;
  }
  else {
    console.log('mate');
  }
  // HOW DO WE LOOP THROUGH THE WHOLE RADIO BUTTON OPTIONS AND CHECK THE ONE THAT IS SELECTED BY THE USER AND THEN STORE IT IN THE SESSIONSTORAGE JS ?????? //
}


/*    if (one.checked == true) {
        localStorage.setItem(one);
        location.reload();
    }
    else if (two.checked == true) {
        localStorage.setItem(two);
        location.reload();
    }
    else if (three.checked == true) {
        localStorage.setItem(three);
        location.reload();
    }
    else if (four.checked == true) {
        localStorage.setItem(four);
        location.reload();
    }
    else if (five.checked == true) {
        localStorage.setItem(five);
        location.reload();
    }
    else if (none.checked == true) {
        localStorage.setItem(none);
        location.reload();
    }*/

  // function test(){

  //     if (document.getElementById('one').checked){
  //       document.getElementById("one1").disabled = true;
  //       // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
  //       document.getElementById('one2').disabled = true;
  //       document.getElementById('one3').disabled = true;
  //       document.getElementById('one4').disabled = true;
  //       document.getElementById('one5').disabled = true;
  //     } 
  //     else {
  //       console.log("hi");
  //     }
  // }

  // setInterval(test,20); // test function refreshes every 20ms //


function member2() {
  var one2 = document.getElementById('one1'); 
  var two2 = document.getElementById('two1'); 
  var three2 = document.getElementById('three1');
  var four2 = document.getElementById('four1'); 
  var five2 = document.getElementById('five1');
  var none2 = document.getElementById("NA2");

  if (one2.checked == true || two2.checked == true || three2.checked == true || four2.checked == true || five2.checked == true || none2.checked == true) {
      document.getElementById('member2').style.display = "none";
      document.getElementById('container_1').style.display = "none";
      document.getElementById('container_2').style.display = "block";
      document.getElementById('member3').style.display = "block";
      document.getElementById('icon3').style.display = "block";
      document.getElementById('icon_3').style.display = "block";
      document.getElementById('member_three').style.display = "block";
      
  } else {
      alert("Please select any one preference to go to next member");
  }


  // For locally storing the selected preference //
  var selection_2 = document.getElementsByName('radio1');

  for (let i = 0; i < selection_2.length; i++) {
      if (selection_2[i].checked) {
          localStorage.setItem("preference2", selection_2[i].value);
      }
  }

  if (document.getElementById('one1').checked){
    document.getElementById("one").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('one2').disabled = true;
    document.getElementById('one3').disabled = true;
    document.getElementById('one4').disabled = true;
    document.getElementById('one5').disabled = true;
  } 
  else {
    console.log("hi");
  }
  
  if (document.getElementById('two1').checked) {
    document.getElementById("two").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('two2').disabled = true;
    document.getElementById('two3').disabled = true;
    document.getElementById('two4').disabled = true;
    document.getElementById('two5').disabled = true;
  }
  else {
  console.log("yo");
  }
  
  if (document.getElementById('three1').checked) {
  document.getElementById("three").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('three2').disabled = true;
    document.getElementById('three3').disabled = true;
    document.getElementById('three4').disabled = true;
    document.getElementById('three5').disabled = true;
  }
  else {
  console.log("yoyo");
  }
  
  if (document.getElementById('four1').checked) {
  document.getElementById("four").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('four2').disabled = true;
    document.getElementById('four3').disabled = true;
    document.getElementById('four4').disabled = true;
    document.getElementById('four5').disabled = true;
  }
  else {
  console.log('hehe');
  }
  
  if (document.getElementById('five1').checked) {
  document.getElementById("five").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('five2').disabled = true;
    document.getElementById('five3').disabled = true;
    document.getElementById('five4').disabled = true;
    document.getElementById('five5').disabled = true;
  }
  else {
  console.log('lol');
  }

  if (document.getElementById('NA2').checked) {
    document.getElementById("NA").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('NA3').disabled = true;
    document.getElementById('NA4').disabled = true;
    document.getElementById('NA5').disabled = true;
    document.getElementById('NA6').disabled = true;
  }
  else {
    console.log('mate');
  }

  // For sessionStorage //
  // for (let i = 0; i < selection_2.length; i++) {
  //     if (selection_2[i].checked) {
  //         sessionStorage.setItem("preference2", selection_2[i].value);
  //     }
  // }

  // if (document.getElementById('one').checked == true) {
  //   document.getElementById('one1').style.display = "<style>.one1 (visibility: collapse)";
  //   console.log("hi");
  // }
  // else if (document.getElementById('two').checked == true) {
  //   document.getElementById('two1').disabled = true;
  // }
  // else if (three.checked == true) {
  //   three2.disabled = true;
  // }
  // else if (four.checked == true) {
  //   four2.disabled = true;
  // }
  // else if (five.checked == true) {
  //   five2.disabled = true;
  // }
  // else if (none.checked == true) {
  //   none2.disabled = true;
  // }
  

};


function member3() {
  var one3 = document.getElementById('one1'); 
  var two3 = document.getElementById('two1'); 
  var three3 = document.getElementById('three1');
  var four3 = document.getElementById('four1'); 
  var five3 = document.getElementById('five1');
  var none3 = document.getElementById("NA2");

  if (one3.checked == true || two3.checked == true || three3.checked == true || four3.checked == true || five3.checked == true || none3.checked == true) {
      document.getElementById('member3').style.display = "none";
      document.getElementById('container_2').style.display = "none";
      document.getElementById('container_3').style.display = "block";
      document.getElementById('member4').style.display = "block";
      document.getElementById('icon4').style.display = "block";
      document.getElementById('icon_4').style.display = "block";
      document.getElementById('member_four').style.display = "block";
      
  } else {
      alert("Please select any one preference to go to next member");
  }

  var selection_3 = document.getElementsByName('radio2');

  // For localStorage //
  for (let i = 0; i < selection_3.length; i++) {
      if (selection_3[i].checked) {
          localStorage.setItem("preference3", selection_3[i].value);
      }
  }

  if (document.getElementById('one2').checked){
    document.getElementById("one").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('one1').disabled = true;
    document.getElementById('one3').disabled = true;
    document.getElementById('one4').disabled = true;
    document.getElementById('one5').disabled = true;
  } 
  else {
    console.log("hi");
  }
  
  if (document.getElementById('two2').checked) {
    document.getElementById("two").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('two1').disabled = true;
    document.getElementById('two3').disabled = true;
    document.getElementById('two4').disabled = true;
    document.getElementById('two5').disabled = true;
  }
  else {
  console.log("yo");
  }
  
  if (document.getElementById('three2').checked) {
  document.getElementById("three").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('three1').disabled = true;
    document.getElementById('three3').disabled = true;
    document.getElementById('three4').disabled = true;
    document.getElementById('three5').disabled = true;
  }
  else {
  console.log("yoyo");
  }
  
  if (document.getElementById('four2').checked) {
  document.getElementById("four").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('four1').disabled = true;
    document.getElementById('four3').disabled = true;
    document.getElementById('four4').disabled = true;
    document.getElementById('four5').disabled = true;
  }
  else {
  console.log('hehe');
  }
  
  if (document.getElementById('five2').checked) {
  document.getElementById("five").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('five1').disabled = true;
    document.getElementById('five3').disabled = true;
    document.getElementById('five4').disabled = true;
    document.getElementById('five5').disabled = true;
  }
  else {
  console.log('lol');
  }

  if (document.getElementById('NA3').checked) {
    document.getElementById("NA").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('NA2').disabled = true;
    document.getElementById('NA4').disabled = true;
    document.getElementById('NA5').disabled = true;
    document.getElementById('NA6').disabled = true;
  }
  else {
    console.log('mate');
  }

  // For sessionStorage //
  // for (let i = 0; i < selection_3.length; i++) {
  //     if (selection_3[i].checked) {
  //         sessionStorage.setItem("preference3", selection_3[i].value);
  //     }
  // }

}

function member4() {
  var one4 = document.getElementById('one3'); 
  var two4 = document.getElementById('two3'); 
  var three4 = document.getElementById('three3');
  var four4 = document.getElementById('four3'); 
  var five4 = document.getElementById('five3');
  var none4 = document.getElementById("NA4");

  if (one4.checked == true || two4.checked == true || three4.checked == true || four4.checked == true || five4.checked == true || none4.checked == true) {
      document.getElementById('member4').style.display = "none";
      document.getElementById('container_3').style.display = "none";
      document.getElementById('container_4').style.display = "block";
      document.getElementById('member_five').style.display = "block";
      document.getElementById('member5').style.display = "block";
      document.getElementById('icon5').style.display = "block";
      document.getElementById('icon_5').style.display = "block";
      
  } else {
      alert("Please select any one preference to go to next member");
  }

  var selection_4 = document.getElementsByName('radio3');

  // For localStorage //
  for (let i = 0; i < selection_4.length; i++) {
      if (selection_4[i].checked) {
          localStorage.setItem("preference4", selection_4[i].value);
      }
  }

  if (document.getElementById('one3').checked){
    document.getElementById("one").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('one1').disabled = true;
    document.getElementById('one2').disabled = true;
    document.getElementById('one4').disabled = true;
    document.getElementById('one5').disabled = true;
  } 
  else {
    console.log("hi");
  }
  
  if (document.getElementById('two3').checked) {
    document.getElementById("two").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('two1').disabled = true;
    document.getElementById('two2').disabled = true;
    document.getElementById('two4').disabled = true;
    document.getElementById('two5').disabled = true;
  }
  else {
  console.log("yo");
  }
  
  if (document.getElementById('three3').checked) {
  document.getElementById("three").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('three1').disabled = true;
    document.getElementById('three2').disabled = true;
    document.getElementById('three4').disabled = true;
    document.getElementById('three5').disabled = true;
  }
  else {
  console.log("yoyo");
  }
  
  if (document.getElementById('four3').checked) {
  document.getElementById("four").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('four1').disabled = true;
    document.getElementById('four2').disabled = true;
    document.getElementById('four4').disabled = true;
    document.getElementById('four5').disabled = true;
  }
  else {
  console.log('hehe');
  }
  
  if (document.getElementById('five3').checked) {
  document.getElementById("five").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('five1').disabled = true;
    document.getElementById('five2').disabled = true;
    document.getElementById('five4').disabled = true;
    document.getElementById('five5').disabled = true;
  }
  else {
  console.log('lol');
  }

  if (document.getElementById('NA4').checked) {
    document.getElementById("NA").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('NA2').disabled = true;
    document.getElementById('NA3').disabled = true;
    document.getElementById('NA5').disabled = true;
    document.getElementById('NA6').disabled = true;
  }
  else {
    console.log('mate');
  }

  // For sessionStorage //
  
}

function member5() {
  var one5 = document.getElementById('one4'); 
  var two5 = document.getElementById('two4'); 
  var three5 = document.getElementById('three4');
  var four5 = document.getElementById('four4'); 
  var five5 = document.getElementById('five4');
  var none5 = document.getElementById("NA5");

  if (one5.checked == true || two5.checked == true || three5.checked == true || four5.checked == true || five5.checked == true || none5.checked == true) {
      document.getElementById('member5').style.display = "none";
      document.getElementById('container_4').style.display = "none";
      document.getElementById('container_5').style.display = "block";
      document.getElementById('member_five').style.display = "none";
      document.getElementById('member-6').style.display = "block";
      document.getElementById('member_5').style.display = "none";
      document.getElementById('member_six').style.display = "block";
      document.getElementById('finish-off').style.display = "block";
      document.getElementById('finish').style.display = "block";
      
  } else {
      alert("Please select any one preference to go to next member");
  }

  var selection_5 = document.getElementsByName('radio4');

  // For localStorage for vote for Lucrecia //
  for (let i = 0; i < selection_5.length; i++) {
      if (selection_5[i].checked) {
          localStorage.setItem("preference5", selection_5[i].value);
      }
  }

  if (document.getElementById('one4').checked){
    document.getElementById("one1").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('one2').disabled = true;
    document.getElementById('one3').disabled = true;
    document.getElementById('one').disabled = true;
    document.getElementById('one5').disabled = true;
  } 
  else {
    console.log("hi");
  }
  
  if (document.getElementById('two4').checked) {
    document.getElementById("two1").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('two2').disabled = true;
    document.getElementById('two3').disabled = true;
    document.getElementById('two').disabled = true;
    document.getElementById('two5').disabled = true;
  }
  else {
  console.log("yo");
  }
  
  if (document.getElementById('three4').checked) {
  document.getElementById("three1").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('three2').disabled = true;
    document.getElementById('three3').disabled = true;
    document.getElementById('three').disabled = true;
    document.getElementById('three5').disabled = true;
  }
  else {
  console.log("yoyo");
  }
  
  if (document.getElementById('four4').checked) {
  document.getElementById("four1").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('four2').disabled = true;
    document.getElementById('four3').disabled = true;
    document.getElementById('four').disabled = true;
    document.getElementById('four5').disabled = true;
  }
  else {
  console.log('hehe');
  }
  
  if (document.getElementById('five4').checked) {
  document.getElementById("five1").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('five2').disabled = true;
    document.getElementById('five3').disabled = true;
    document.getElementById('five').disabled = true;
    document.getElementById('five5').disabled = true;
  }
  else {
  console.log('lol');
  }

  if (document.getElementById('NA5').checked) {
    document.getElementById("NA").disabled = true;
    // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
    document.getElementById('NA2').disabled = true;
    document.getElementById('NA3').disabled = true;
    document.getElementById('NA4').disabled = true;
    document.getElementById('NA6').disabled = true;
  }
  else {
    console.log('mate');
  }

  // For sessionStorage for vote for Lucrecia //

}

function done() {

  var selection_6 = document.getElementsByName('radio5');

        // For localStorage for vote of Mouna //
        for (let i = 0; i < selection_6.length; i++) {

          if (selection_6[i].checked) {
            localStorage.setItem("preference6", selection_6[i].value);
          }
        }
        
        if (document.getElementById('one5').checked){
          document.getElementById("one1").disabled = true;
          // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
          document.getElementById('one2').disabled = true;
          document.getElementById('one3').disabled = true;
          document.getElementById('one4').disabled = true;
          document.getElementById('one').disabled = true;
        } 
        else {
          console.log("hi");
        }
        
        if (document.getElementById('two4').checked) {
          document.getElementById("two1").disabled = true;
          // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
          document.getElementById('two2').disabled = true;
          document.getElementById('two3').disabled = true;
          document.getElementById('two4').disabled = true;
          document.getElementById('two').disabled = true;
        }
        else {
        console.log("yo");
        }
        
        if (document.getElementById('three4').checked) {
        document.getElementById("three1").disabled = true;
          // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
          document.getElementById('three2').disabled = true;
          document.getElementById('three3').disabled = true;
          document.getElementById('three4').disabled = true;
          document.getElementById('three').disabled = true;
        }
        else {
        console.log("yoyo");
        }
        
        if (document.getElementById('four4').checked) {
        document.getElementById("four1").disabled = true;
          // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
          document.getElementById('four2').disabled = true;
          document.getElementById('four3').disabled = true;
          document.getElementById('four4').disabled = true;
          document.getElementById('four').disabled = true;
        }
        else {
        console.log('hehe');
        }
        
        if (document.getElementById('five4').checked) {
        document.getElementById("five1").disabled = true;
          // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
          document.getElementById('five2').disabled = true;
          document.getElementById('five3').disabled = true;
          document.getElementById('five4').disabled = true;
          document.getElementById('five').disabled = true;
        }
        else {
        console.log('lol');
        }

        if (document.getElementById('NA6').checked) {
          document.getElementById("NA").disabled = true;
          // document.getElementById('one1', 'one2', 'one3', 'one4', 'one5').innerHTML = "<style>(background-color: grey)";
          document.getElementById('NA2').disabled = true;
          document.getElementById('NA3').disabled = true;
          document.getElementById('NA4').disabled = true;
          document.getElementById('NA5').disabled = true;
        }
        else {
          console.log('mate');
        }

        // For sessionStorage for vote of Mouna //

        location.href = "thanks.html";

        /* document.getElementById('confirm').style.display = "none";
        document.getElementById("finish").style.display = "block";
        document.getElementById("container_5").style.display = "none";
        document.getElementById("review_container").style.display = "block"; 

        document.getElementById("voter_email").innerHTML = sessionStorage.getItem("email");
        document.getElementById("voter_grade").innerHTML = sessionStorage.getItem("grade");
        document.getElementById("src_member1").innerHTML = sessionStorage.getItem("preference1");
        document.getElementById("src_member2").innerHTML = sessionStorage.getItem("preference2");
        document.getElementById("src_member3").innerHTML = sessionStorage.getItem("preference3");
        document.getElementById("src_member4").innerHTML = sessionStorage.getItem("preference4");
        document.getElementById("src_member5").innerHTML = sessionStorage.getItem("preference5");
        document.getElementById("src_member6").innerHTML = sessionStorage.getItem("preference6"); */

}


/* function member_2() {
  document.getElementById('container_1').style.display = "none";
  document.getElementById('container').style.display = "block";
} */

// function verify() {
//     var span = document.getElementById("span_id");
//     var inputs = span.getElementsByTagName("input");

//     for (var i = 0; i < inputs.length; ++i) {
//         if (inputs[i].checked == true) {
//             sessionStorage.setItem("preference", inputs[i])
//         }
//     }
// }


// Going backwards //
function member_2() {
  document.getElementById('container_2').style.display = "none";
  document.getElementById('container_1').style.display = "none";
  document.getElementById('container').style.display = "block";
  document.getElementById('member2').style.display = "none";
  document.getElementById('member1').style.display = "block";
  document.getElementById('icon_2').style.display = "none";
}

function member_3() {
  document.getElementById('container_3').style.display = "none";
  document.getElementById('container_2').style.display = "none";
  document.getElementById('container_1').style.display = "block";
  document.getElementById('member3').style.display = "none";
  document.getElementById('member2').style.display = "block";
  document.getElementById('icon_3').style.display = "none";
}

function member_4() {
  document.getElementById('container_4').style.display = "none";
  document.getElementById('container_3').style.display = "none";
  document.getElementById('container_2').style.display = "block";
  document.getElementById('member4').style.display = "none";
  document.getElementById('member3').style.display = "block";
  document.getElementById('icon_4').style.display = "none";
}

function member_5() {
  document.getElementById('container_5').style.display = "none";
  document.getElementById('container_4').style.display = "none";
  document.getElementById('container_3').style.display = "block";
  document.getElementById('member5').style.display = "none";
  document.getElementById('member4').style.display = "block";
  document.getElementById('icon_5').style.display = "none";
}

function member_6() {
  document.getElementById('container_5').style.display = "none";
  document.getElementById('container_4').style.display = "block";
  document.getElementById('finish-off').style.display = "none";
  document.getElementById('finish').style.display = "none";
  document.getElementById('member5').style.display = "block";
  document.getElementById('member_5').style.display = "block";
}

// WE ARE ALSO THINKING TO LET THE USERS REVIEW THEIR VOTES //


/* METHOD 2 - To get the user data from radio buttons */



/* For validating preferences */
/* function member1() {
  if (document.getElementById('#').value == "") {
      alert("You must select your preference");
  } else {
      return;
  }
} */
// Basically, users must select their preference, or else, they cannot proceed to vote for next member //

