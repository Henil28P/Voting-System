// Filename: system.js //
// Email validation //
// var arr = ["aphs.nsw.edu.au"];

/* pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
function next() {
    // Email validation //
    if (document.getElementById("mail").value != pattern) {
        alert("You must be an APHS student in order to vote for SRC members, this means that your email must include \"@aphs.nsw.edu.au\"");

    } else {
        location.href="Section1.html";
    }
} */

// Nested if statements //
/* function next() {
    var s1 = document.getElementById('s1').value;
    var s2 = document.getElementById('s2').value;
    var s3 = document.getElementById('s3').value;
    var s4 = document.getElementById('s4').value;
    var s5 = document.getElementById('s5').value;
    var s6 = document.getElementById('s6').value;
    if (document.getElementById('grade').value != s1 | s2 | s3 | s4 | s5 |s6) {
        alert ("Please select your grade");
    } else {
        window.open("voting.html");
    }
} */

// Nexted if statements //
/* function next() {
    if (!document.getElementById("mail").value == "jesusa.mercado@aphs.nsw.edu.au") {
        window.open("./voting.html");
    }
    else if (!document.getElementById("mail").value.includes("@aphs.nsw.edu.au")) {
        alert("You must be an APHS student in order to vote for SRC members, this means that your email must include \"@aphs.nsw.edu.au\"");
        location.href = "#";
    }
    else {
        unique = prompt("Enter unique key");

        if (unique == "37KXCQ02") {
            window.open("results.html");
        } 
        else {
            alert("INCORRECT identification key entered, please try again!");
            location.href = "#";
        }
    }

} */
    /* const mail = document.getElementById('mail');
    const grade = document.getElementById('grade');

        function finish() {
            const email = mail.value;
            const year = grade.value;

    
            localStorage.setItem(email, year);
            location.reload();

            location.href = "form_demo[2].html";
        };


    /* var email;
    email = "jesusa.mercado@aphs.nsw.edu.au"; */

    /* if (document.getElementById("mail").value == "jesusa.mercado@aphs.nsw.edu.au") {

        /* var unique;
        id = "37-KX-CQ-02"; */
        
        /* unique = prompt("Enter unique key");

        if (unique == "37KXCQ02") {
            window.open("results.html");
            // window.open("results.html");
        }

        else {
            location.href = "#";
            
        }







        /* document.getElementById("x").style.display = "block";
        document.getElementById("unique").style.display = "inline";

        /* window.open("./results.html"); */
        // key = document.getElementById("unique").value;

        /* if (key === "37-KX-CQ-02") {
            window.open("./results.html");
        }

        else {
            alert("INCORRECT identification key entered, please try again!");
            location.href = "#";
        } */
    /* }
        





    else {
        if (document.getElementById('mail').value.includes("@aphs.nsw.edu.au")) {
            window.open("./voting.html");
        }

        else {
            alert("You must be an APHS student in order to vote for SRC members, this means that your email must include \"@aphs.nsw.edu.au\"");
            location.href = "#";
        }
    }
}

// METHOD 2 - To get the user data //
/* document.getElementById("hidden").value = document.getElementById('mail').value;
document.getElementById("hidden_1").value = document.getElementById('grade').value; */



/* function next() {
    if (email.includes("@aphs.nsw.edu.au")) {
        window.open("./voting.html");
    }

    else {
        alert("You must be an APHS student in order to vote for SRC members, this means that your email must include \"@aphs.nsw.edu.au\"");
        window.open("#");
    }
} */

    /* if (email.includes("@aphs.nsw.edu.au")) {
        window.open("./voting.html");

    } else {
        alert("You must be an APHS student in order to vote for SRC members, this means that your email must include \"@aphs.nsw.edu.au\"");
        location.href = "#";
    } */

    /* if (email === "jesusa.mercado@aphs.nsw.edu.au") {
        location.href = "results.html";
    } */

    /* function finish() {
        const email = document.getElementById('mail').value;
        const year = document.getElementById('grade').value;

        localStorage.setItem(email, year);
        location.reload();

        var one = document.getElementById("one").value;
        var two = document.getElementById("two").value;
        var three = document.getElementById("three").value;

        if (one.checked == true) {
            localStorage.setItem(one);
            location.reload();
        }
        else if (two.checked == true) {
            localStorage.setItem(two);
            location.reload();
        }
        else if (three.checked == true) {
            localStorage.setItem(three);
            location.reload();
        }

        // make a new var
        /* var random = one.checked || two.checked || three.checked ;

        if (random == true) {
            localStorage.setItem(email, year, random);
            location.reload();

            location.href = "form_demo[2].html";
        } */
    // };