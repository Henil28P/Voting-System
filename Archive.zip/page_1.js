// Filename: page_1.js linked to filename index.html and other HTML files in this system folder //

    function next() {
        email = document.getElementById('mail').value;

        // Nested if statements //
        if (email == "jesusa.mercado@aphs.nsw.edu.au") { 
            // For client security //

            var unique = prompt("Enter unique key"); // User input of given unique key to client to confirm it is the client //
            var lower_unique = unique.toLowerCase();

            if (lower_unique == "37kxcq02") { // given only to client to access results //
                window.open("results.html"); // Direct the user (client) to results.html page //
            }

            else {
                location.href = "#"; // Reload user's page if he/she doesn't enter the correct pin as per client security purposes //
            }
        }

        else {
            // For school security //
            if (email.includes("@aphs.nsw.edu.au")) {

                window.open("./voting.html"); // Direct the user to voting.html if his/her email includes @aphs.nsw.edu.au //
            }

            else {
                alert("You must be an APHS student in order to vote for SRC members, this means that your email must include \"@aphs.nsw.edu.au\"");
                location.href = "#"; // Reload user's page and don't let him/her go to the next page if email doesn't include @aphs.nsw.edu.au //
            }
        }

        const grade = document.getElementById('grade').value;

        localStorage.setItem("email", email);
        localStorage.setItem("grade", grade);
        location.reload();

        // Firebase concept to store data //
        /* var firebaseConfig = {
            apiKey: "AIzaSyBFMDCD8ZfCojZQHxw86HMQBl8RtcuZ9R8",
            authDomain: "src-user-data.firebaseapp.com",
            projectId: "src-user-data",
            storageBucket: "src-user-data.appspot.com",
            messagingSenderId: "658974945217",
            appId: "1:658974945217:web:29686db3f724f1a345c940",
            measurementId: "G-RNLCWKL02M"
          }; */

          // Initialize Firebase
          /*firebase.initializeApp(firebaseConfig);
          firebase.analytics();

          database = firebase.database();

          var ref = database.ref('scores');

          var data = {
              mail: email,
              year: grade
          }

          console.log(data);
          var ref = database.ref('scores');
          ref.push(data);
    
        location.href = "results.html";

    } */



    // To check if the unique key entered is correct or incorrect
    /* function next() {
        if (!document.getElementById("mail").value == "jesusa.mercado@aphs.nsw.edu.au") {
            window.open("./voting.html");
        }
        else if (!document.getElementById("mail").value.includes("@aphs.nsw.edu.au")) {
            alert("You must be an APHS student in order to vote for SRC members, this means that your email must include \"@aphs.nsw.edu.au\"");
            location.href = "#";
        }
        else {
            unique = prompt("Enter unique key");
    
            if (unique == "37KXCQ02") {
                window.open("results.html");
            } 
            else {
                alert("INCORRECT identification key entered, please try again!");
                location.href = "#";
            }
        } */
    
    }